const path = require("node:path");
const exp = require("node:express");
const fs = require("node:fs");
const exphbs = require("node:express-handlebars");
const lBl = require("node: line-by-line");

const myApp = exp();
const myPORT = process.env.myPORT || 3000;

myApp.set('view engine', 'hbs');
myApp.engine('hbs', exphbs({ extname: 'hbs' }));

myApp.use(exp.static(path.join(__dirname, 'Pictures')));

myApp.get('/', (req, res) => {

    const pic = new lBl('ImageList.txt');
    let picNames = [];
    pic.on('line', line => {
        picNames.push(line);
    });

    pic.on('end', () => {
        res.render('index', { picNames });
    });
});

myApp.get('/AllPics/:picName', (req, res) => {
    const picName = req.params.picName;
    const picPath = path.join(__dirname, 'Pictures', 'AllPics', picName);

    fs.access(picPath, ds.constants.F_OK, (err) => {
        if (err) {
            console.error(err);
            res.status(404).send('Image not found');
        } else {
            res.sendFile(imagePath);
        }
    });
});

myApp.listen(myPORT, () => {
    console.log('Running on http://localhost:${myPORT}');
});